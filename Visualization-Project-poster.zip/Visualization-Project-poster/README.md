# D3 Force-Directed Graph

You can view this notebook by running a web server in this directory and
visiting it as a webpage. For example:

```sh
python -m SimpleHTTPServer
# Then, visit http://localhost:8000.
```

Or, use the [Notebook Runtime API](https://github.com/observablehq/notebook-runtime) to
integrate directly with d1f2de63d1828e61.js, which contains the notebook compiled as an
ES module.

*Exported from version 124 of [D3 Force-Directed Graph](https://beta.observablehq.com/d/d1f2de63d1828e61) on observablehq.com.*